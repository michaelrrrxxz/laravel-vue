<?php

use App\Http\Controllers\ProductController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\PostController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\DashboardController;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');



// Route::get('/' , function(){
//    return 'hello';
// });

// Route:: POST('/post/add',[PostController::class, 'store']);
// Route::GET('/post',[PostController::class, 'index']);


Route::prefix('/')->group(function () {
    Route::apiResource('post', PostController::class);
});

Route::middleware('guest')->group(function () {
    Route::prefix('/')->group(function () {
        Route::controller(AuthController::class)->group(function () {
            Route::post('/register', 'register');
            Route::post('/login', 'login')->name('login');
            Route::post('/logout', 'logout');
        });
    });
});


Route::prefix('products')->group(function () {
    Route::get('/', [ProductController::class, 'index']);
    Route::post('/store', [ProductController::class, 'store']);
    Route::get('/count', [ProductController::class, 'count']);
});



route::apiResource('users', UserController::class);
route::get('/countUsers', [DashboardController::class, 'countUsers']);
