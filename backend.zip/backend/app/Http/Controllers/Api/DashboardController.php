<?php

namespace App\Http\Controllers\Api;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
   public function countUsers(){
    $users = User::count();
    return response()->json(["count"=>$users]);
   }
}
